This Compiler Contains Private Info About SDS (Passwords), So Please Don't Redistribute The Compiler.exe File

Bat To EXE Compiler By Fatih Kodak